# IR Extension
Custom IR communication extension for MakeCode using C++ implementation.