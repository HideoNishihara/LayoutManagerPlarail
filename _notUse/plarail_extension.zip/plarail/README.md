# Plarail IR Extension for micro:bit

This MakeCode extension enables IR communication for controlling Plarail models.