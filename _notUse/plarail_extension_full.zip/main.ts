//% weight=100 color=#0fbc11 icon="🚂"
//% block="Plarail IR"
namespace plarail {
    //% blockId="plarail_send_ir" block="send IR to train with ID %id| direction %direction| speed %speed"
    //% id.min=0 id.max=15 direction.min=0 direction.max=3 speed.min=0 speed.max=255
    export function sendIR(id: number, direction: number, speed: number): void {
        sendIRNative(id, direction, speed);
    }

    //% blockId="plarail_on_receive" block="on IR command received"
    export function onIRReceive(handler: (id: number, cmd: number) => void): void {
        control.onEvent(3100, 1, () => {
            const trainID = receivedID();
            const command = receivedCommand();
            handler(trainID, command);
        });
    }

    // shim to native C++
    //% shim=plarail::sendIRNative
    declare function sendIRNative(id: number, direction: number, speed: number): void;

    //% shim=plarail::receivedID
    declare function receivedID(): number;

    //% shim=plarail::receivedCommand
    declare function receivedCommand(): number;
}
