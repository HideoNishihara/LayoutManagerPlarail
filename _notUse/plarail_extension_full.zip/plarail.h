#pragma once
namespace plarail {
    void sendIRNative(int id, int direction, int speed);
    int receivedID();
    int receivedCommand();
}
