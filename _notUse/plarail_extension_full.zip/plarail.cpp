#include "pxt.h"
using namespace pxt;

#define IR_PIN         MICROBIT_PIN_P1
#define RED_LED        MICROBIT_PIN_P14
#define BLUE_LED       MICROBIT_PIN_P15
#define VMON_PIN       MICROBIT_PIN_P2

#define EVENT_ID       3100

namespace plarail {
    static int lastID = 0;
    static int lastCmd = 0;

    void sendIRNative(int id, int direction, int speed) {
        RED_LED.setDigitalValue(1);
        fiber_sleep(50);
        RED_LED.setDigitalValue(0);
        // 送信プロトコルはここに実装（例：NEC準拠など）
    }

    int receivedID() {
        return lastID;
    }

    int receivedCommand() {
        return lastCmd;
    }

    void irReceiveHandler() {
        // ダミー処理（実装次第でIR信号を解析）
        lastID = 1;
        lastCmd = 2;
        pxt::control::raiseEvent(EVENT_ID, 1);
        BLUE_LED.setDigitalValue(1);
        fiber_sleep(50);
        BLUE_LED.setDigitalValue(0);
    }

    void monitorVoltage() {
        while (true) {
            int value = VMON_PIN.getAnalogValue(); // 0-1023
            float voltage = value * 3.3f * 2 / 1023.0f;
            if (voltage < 3.75f) {
                RED_LED.setDigitalValue(1);
                fiber_sleep(50);
                RED_LED.setDigitalValue(0);
                fiber_sleep(2000);
            } else {
                fiber_sleep(500);
            }
        }
    }

    // 初期化タスク
    void init() {
        create_fiber(irReceiveHandler);
        create_fiber(monitorVoltage);
    }

    // 自動実行
    //% shim=pxtrt::runFiber
    void __init__() {
        init();
    }
}
